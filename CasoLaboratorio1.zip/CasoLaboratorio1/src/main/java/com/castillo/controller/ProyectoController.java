package com.castillo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.castillo.modelo.Empleado;
import com.castillo.repositorios.IEmpleadoService;

@Controller
public class ProyectoController {

	@Autowired
	private IEmpleadoService service;
	
	@GetMapping("/verListado")
	public String verListado(Model model) {
		model.addAttribute("listado", service.obtenerEmpleados());
		return "Listado";
	}
	
	@GetMapping("/formRegistro")
	public String formRegistro(Model model) {
		model.addAttribute("empleado", new Empleado());
		return "FormRegistro";
	}
	
	@GetMapping("/formEditar")
	public String formEditar(@RequestParam("id") String id, Model model) {
		model.addAttribute("empleado", service.encontrarEmpleado(id));
		return "FormEditar";
	}
	
	@PostMapping("/submitRegistro")
	public String submitRegistro(@ModelAttribute("empleado") Empleado nuevo) {
		service.guardarCambios(nuevo);
		return "redirect:/verListado";
	}
	
	@PostMapping("/submitEditar")
	public String submitEditar(@ModelAttribute("empleado") Empleado editado) {
		service.guardarCambios(editado);
		return "redirect:/verListado";
	}
	
	@GetMapping("/eliminar")
	public String eliminar(@RequestParam("id") String id) {
		service.eliminarEmpleado(service.encontrarEmpleado(id));
		return "redirect:/verListado";
	}
}
