package com.castillo.modelo;

import jakarta.persistence.*;
import lombok.*;

@Data
@Entity
@Table(name = "Empleados")
public class Empleado {

	@Id
	private String idempleado;
	private String apellidos;
	private String nombres;
	private int edad;
	private char sexo;
	private double salario;
}
