package com.castillo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CasoLaboratorio1Application {

	public static void main(String[] args) {
		SpringApplication.run(CasoLaboratorio1Application.class, args);
	}

}
