package com.castillo.repositorios;

import java.util.List;

import com.castillo.modelo.Empleado;

public interface IEmpleadoService {

	void guardarCambios(Empleado empleado);
	Empleado encontrarEmpleado(String id);
	void eliminarEmpleado(Empleado empleado);
	List<Empleado> obtenerEmpleados();
}
