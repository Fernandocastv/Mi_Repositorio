package com.castillo.repositorios;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.castillo.modelo.Empleado;

@Repository
public interface EmpleadoRepository extends JpaRepository<Empleado, String>{

}
