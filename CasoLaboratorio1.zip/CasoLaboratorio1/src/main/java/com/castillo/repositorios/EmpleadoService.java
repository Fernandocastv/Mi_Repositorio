package com.castillo.repositorios;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.castillo.modelo.Empleado;

@Service
public class EmpleadoService implements IEmpleadoService {

	@Autowired
	private EmpleadoRepository empleadoRepository;
	
	@Override
	public void guardarCambios(Empleado empleado) {
		empleadoRepository.save(empleado);
	}

	@Override
	public Empleado encontrarEmpleado(String id) {
		return empleadoRepository.findById(id).get();
	}

	@Override
	public void eliminarEmpleado(Empleado empleado) {
		empleadoRepository.delete(empleado);
	}

	@Override
	public List<Empleado> obtenerEmpleados() {
		return empleadoRepository.findAll();
	}

}
